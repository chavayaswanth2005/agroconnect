package com.klu;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class AgroConnectApplication {
    public static void main(String[] args) {
        SpringApplication.run(AgroConnectApplication.class, args);
    }
}
